Ansible role for Azure Red Hat OpenShift cluster Creation and Deletion.

Requirements

Ansible >= v2.9
Linux Environment
ansible-galaxy collection install azure.azcollection
pip3 -r install -r https://raw.githubusercontent.com/ansible-collections/azure/dev/requirements-azure.txt

Variables:

---
location: westus2
resource_group: rg-azure-roc
cluster: azure-ro-cluster
domain_name: openshiftws.com
master_size : Standard_D8s_v3
worker_size : Standard_D4s_v3
azure_roc_creation: "True"
worker_count: 3 #min is 3, we cant give lesser than this.
disk_size: 128



